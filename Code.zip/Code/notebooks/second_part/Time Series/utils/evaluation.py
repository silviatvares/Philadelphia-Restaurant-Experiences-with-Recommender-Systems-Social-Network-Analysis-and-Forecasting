import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import root_mean_squared_error, mean_absolute_error, mean_absolute_percentage_error
import seaborn as sns

class Evaluator:
    def __init__(self):
        self.results = {}  # To store evaluation results for each model
    
    def evaluate_model(self, model_name, y_true, y_pred):
        """
        Evaluate a single model's performance and store results.
        """
        rmse = root_mean_squared_error(y_true, y_pred)
        mae = mean_absolute_error(y_true, y_pred)
        mape = mean_absolute_percentage_error(y_true, y_pred)


        self.results[model_name] = {
            'RMSE': rmse,
            'MAE': mae,
            # 'MAPE': mape,
            
        }
        
        print(f"Evaluation of {model_name}:")
        print(f"  - RMSE: {rmse:.4f}")
        print(f"  - MAE: {mae:.4f}")
        print(f"  - MAPE: {mape:.4f}")

        return self.results[model_name]

    def plot_forecast_vs_actual(self, y_train, y_true, y_pred, model_name):
        """
        Plot forecasted vs actual values for a single model.
        """
        plt.figure(figsize=(10, 5))
        plt.plot(y_train.index, np.concatenate(y_train.values), label="Historicla Data", color="blue")
        plt.plot(y_true.index, np.concatenate(y_true.values), label="Actual", color="blue", alpha=0.3)
        plt.plot(y_true.index, y_pred, label=f"Forecast ({model_name})", color="red")
        #plt.fill_between(y_true.index, y_pred, np.concatenate(y_true.values), color="gray", alpha=0.2)
        plt.title(f"Actual vs Forecast - {model_name}")
        plt.xlabel("Date")
        plt.ylabel("Checkins")
        plt.legend()
        plt.show()

    def compare_models_metrics(self):
        """
        Compare metrics of all evaluated models and visualize them in a bar plot with a blue color palette.
        """
        # Convert the nested dictionary of results into a DataFrame
        metrics_df = pd.DataFrame(self.results)
        
        # Reset index so that model names become a column for plotting
        metrics_df = metrics_df.reset_index().rename(columns={'index': 'Metric'})
        
        # Melt the DataFrame to long format for easier plotting with seaborn
        metrics_df_melted = metrics_df.melt(id_vars='Metric', var_name='Model', value_name='Value')

        plt.figure(figsize=(12, 6))
        
        # Use seaborn's barplot and apply the 'Blues' color palette
        sns.barplot(x='Metric', y='Value', hue='Model', data=metrics_df_melted, palette="Blues")
        
        # Titles and labels
        plt.title("Comparison of Model Metrics", fontsize=16, fontweight='bold')
        plt.xlabel("Metric", fontsize=14)
        plt.ylabel("Metric Value", fontsize=14)
        
        # Rotate x-axis labels for better readability
        plt.xticks(rotation=45, ha="right")
        
        # Add a grid for readability
        plt.grid(True, linestyle='--', alpha=0.6)
        
        plt.tight_layout()
        plt.show()

    def evaluate_and_plot(self, model_name, y_train, y_true, y_pred):
        """
        Evaluate a model and plot forecast vs actual in one function call.
        """
        self.evaluate_model(model_name, y_true, y_pred)
        self.plot_forecast_vs_actual(y_train, y_true, y_pred, model_name)

    @classmethod
    def plot_errors_cv_comparison(cls, errors: dict):
        # Convert the dictionary into a DataFrame for easier manipulation
        errors_df = pd.DataFrame(errors)

        # Set up the figure
        plt.figure(figsize=(12, 8))

        # Create the boxplot
        sns.boxplot(data=errors_df)

        # Add title and labels
        plt.title('Boxplot of Forecast Errors Across Models')
        plt.xlabel('Models')
        plt.ylabel('Forecast Errors')

        # Display the plot
        plt.show()


