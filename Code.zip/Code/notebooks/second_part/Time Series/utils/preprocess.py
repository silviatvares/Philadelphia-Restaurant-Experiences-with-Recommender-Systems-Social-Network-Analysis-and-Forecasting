import pandas as pd
import numpy as np


def get_high_correlation_columns(df: pd.DataFrame, target_col: str, threshold: float = 0.5):
    """
    Get columns with correlation greater than or equal to a positive threshold
    or less than or equal to a negative threshold with respect to the target column.
    
    df: Pandas DataFrame containing the data.
    target_col: The target column to calculate correlation against.
    threshold: Threshold for absolute correlation (default: 0.5).
    
    Returns:
    - A dictionary with column names and their correlation values.
    """
    # Calculate correlations with the target column
    correlations = df.corr()[target_col]
    
    # Filter columns based on correlation threshold
    high_corr_columns = correlations[
        (correlations >= threshold) | (correlations <= -threshold)
    ].sort_values(ascending=False)
    
    # Remove the target column from the result
    high_corr_columns = high_corr_columns.drop(target_col, errors='ignore')
    
    return high_corr_columns.index.to_list()



def filter_high_pairwise_correlation(df: pd.DataFrame, target_col: str, pairwise_threshold: float = 0.70):
    """
    Filter columns starting with 'checkins_' or 'lag_' by pairwise correlation, keeping only those
    with pairwise correlation below the given threshold.

    df: Pandas DataFrame containing the data.
    pairwise_threshold: Maximum allowed pairwise correlation among selected features (default: 0.75).

    Returns:
    - A list of selected column names with pairwise correlation <= pairwise_threshold.
    """
    # Filter columns that start with 'checkins_' or 'lag_'
    relevant_columns = [col for col in df.columns if col.startswith('checkins_') or col.startswith('lag_')]
    also_relevant = df.columns.difference(relevant_columns).to_list()
    
    # Calculate the correlation matrix for the filtered columns
    corr_matrix = df[relevant_columns].corr()
    
    # Initialize a list for selected columns
    selected_columns = []
    
    for col in relevant_columns:
        # Check if this column has pairwise correlation <= pairwise_threshold with all already selected columns
        is_valid = True
        for selected_col in selected_columns:
            if abs(corr_matrix[col][selected_col]) > pairwise_threshold:
                is_valid = False
                break
        if is_valid:
            selected_columns.append(col)
    
    selected_columns.extend(also_relevant)
    return selected_columns