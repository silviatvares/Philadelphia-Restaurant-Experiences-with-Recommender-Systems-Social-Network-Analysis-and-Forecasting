from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import root_mean_squared_error, mean_absolute_error
import pandas as pd
import numpy as np
from .base_model import TimeSeriesModel

class RandomForestModel(TimeSeriesModel):

    def train(self):
        """Train the Random Forest model."""
        self.model = RandomForestRegressor(n_estimators=100, random_state=42)
        self.model.fit(self.X_train, self.y_train)

    def predict(self, X):
        """Predict using Random Forest."""
        return self.model.predict(X)

    def evaluate(self, y_true, y_pred):
        return {'mae': mean_absolute_error(y_true, y_pred), 
                'rmse': root_mean_squared_error(y_true, y_pred)}
