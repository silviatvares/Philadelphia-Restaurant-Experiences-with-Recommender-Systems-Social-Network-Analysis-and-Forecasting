from abc import ABC, abstractmethod
from sklearn.model_selection import train_test_split
from utils.preprocess import *


class TimeSeriesModel(ABC):
    def __init__(self, data: pd.DataFrame, target_column: str, horizon: int):
        self.data = data
        self.target_column = target_column
        self.horizon = horizon  # Number of periods to use for testing
        self.model = None


    def preprocess_data(self):
        """Preprocess data for the specific model."""

        # Get high correlation columns
        high_corr_columns = get_high_correlation_columns(self.data, self.target_column)
        filtered_df = self.data[high_corr_columns]
        
        # Filter high pairwise correlation features
        final_columns = filter_high_pairwise_correlation(filtered_df, self.target_column, pairwise_threshold=0.75)
        
        # Create final DataFrame with target variable
        final_df = self.data[final_columns + [self.target_column]].sort_index()
        
        # Separate features and target
        X = final_df.drop(columns=self.target_column)
        y = final_df[[self.target_column]]

        # Use the horizon to split the data
        train_size = len(X) - self.horizon
        self.X_train = X.iloc[:train_size]
        self.X_test = X.iloc[train_size:]
        self.y_train = y.iloc[:train_size]
        self.y_test = y.iloc[train_size:]
        
        return final_df 



    @abstractmethod
    def train(self, X=None, y=None):
        """Train the model on the training set."""
        pass

    @abstractmethod
    def predict(self, X):
        """Predict future values."""
        pass

    @abstractmethod
    def evaluate(self):
        """Evaluate the model performance."""
        pass

    def pipeline(self):
        """Defines the general flow of the model"""
        final_df = self.preprocess_data()
        self.train()
        # After training, return model to allow predictions
        return self
