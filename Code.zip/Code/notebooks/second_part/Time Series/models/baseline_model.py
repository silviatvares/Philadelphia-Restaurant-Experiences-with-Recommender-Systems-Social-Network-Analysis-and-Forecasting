import numpy as np
from sklearn.metrics import mean_absolute_error, mean_absolute_percentage_error, root_mean_squared_error
from statsforecast import StatsForecast
from statsforecast.models import AutoARIMA, Naive, HistoricAverage
import pandas as pd
from .base_model import TimeSeriesModel


class BaselineModel(TimeSeriesModel):

    def train(self):
        """Train baseline model using StatsForecast."""
        # Prepare training data as DataFrame with time and value columns
        y_train_flat = self.y_train.reset_index()  # Reset index to use as a DataFrame
        y_train_flat.columns = ['ds', 'y']  # Rename columns to match the expected format
        y_train_flat['unique_id'] = 0  # Set a constant unique_id for a single time series

        # Fit the model
        self.model = StatsForecast(models=[Naive(alias="last_value")], freq='D')
        self.model.fit(y_train_flat)

    def predict(self, X):
        """Forecast the time series data."""
        # Make predictions using the model
        forecast = self.model.predict(h=self.horizon)
        return forecast["last_value"].values

    def evaluate(self, y_true, y_pred):
        """Evaluate model performance."""
        return {
            'mae': mean_absolute_error(y_true, y_pred), 
            'rmse': root_mean_squared_error(y_true, y_pred) 
        }
