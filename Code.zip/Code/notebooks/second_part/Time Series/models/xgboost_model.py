from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import root_mean_squared_error, mean_absolute_error
import pandas as pd
import numpy as np
from .base_model import TimeSeriesModel

class XGBoostModel(TimeSeriesModel):

    def train(self):
        """Train the XGBoost model."""
        self.model = XGBRegressor(n_estimators=500, learning_rate=0.1, max_depth=5)
        self.model.fit(self.X_train, self.y_train)

    def predict(self, X):
        """Predict using the XGBoost model."""
        return self.model.predict(X)

    def evaluate(self, y_true, y_pred):
        return {'mae': mean_absolute_error(y_true, y_pred), 
                'rmse': root_mean_squared_error(y_true, y_pred)}
