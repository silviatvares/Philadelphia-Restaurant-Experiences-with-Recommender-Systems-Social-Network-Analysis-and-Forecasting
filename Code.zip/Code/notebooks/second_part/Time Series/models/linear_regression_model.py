from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import root_mean_squared_error, mean_absolute_error
import pandas as pd
import numpy as np
from .base_model import TimeSeriesModel

class LinearRegressionModel(TimeSeriesModel):

    def train(self):
        """Train the Linear Regression model."""
        self.model = LinearRegression()
        self.model.fit(self.X_train, self.y_train)

    def predict(self, X):
        """Predict using the trained Linear Regression model."""
        return self.model.predict(X)

    def evaluate(self, y_true, y_pred):
        return {'mae': mean_absolute_error(y_true, y_pred), 
                'rmse': root_mean_squared_error(y_true, y_pred)}
