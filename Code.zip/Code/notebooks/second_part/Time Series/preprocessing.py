import datetime
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from statsmodels.tsa.seasonal import seasonal_decompose, STL
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
from statsmodels.tsa.stattools import adfuller
from statsmodels.tsa.stattools import kpss
from scipy.stats import boxcox
import pandas as pd
import numpy as np
from sklearn.preprocessing import MaxAbsScaler, MinMaxScaler, StandardScaler
from statsmodels.tsa.seasonal import seasonal_decompose
from scipy.signal import savgol_filter
from sklearn.impute import SimpleImputer
from datetime import timedelta
from dateutil.relativedelta import relativedelta
import holidays
from scipy.fft import fft, ifft, dct, idct
import pandas_datareader.data as web
from utilsforecast.feature_engineering import fourier


def handle_missing_values(df, method='ffill'):
    """
    Handle missing values in a time series dataframe.
    method: 'ffill' (Forward Fill), 'bfill' (Backward Fill), or 'mean' (Mean Imputation).
    """
    if method == 'mean':
        return df.fillna(df.mean())
    return df.fillna(method=method)


def resample_timeseries(df: pd.DataFrame, freq='M', method='mean'):
    """
    Resample time series data.
    freq: Resampling frequency ('D', 'W', 'M', etc.).
    method: Aggregation method ('mean', 'sum', etc.).
    """
    if method == 'mean':
        return df.resample(freq).mean()
    elif method == 'sum':
        return df.resample(freq).sum()
    elif method == 'var':
        return df.resample(freq).sum()
    else:
        raise ValueError("Unsupported method")


def scale_minmax(df: pd.DataFrame):
    """
    Normalize time series data using Min-Max Scaling.
    """
    scaler = MinMaxScaler()
    scaled_data = scaler.fit_transform(df)
    return pd.DataFrame(scaled_data, index=df.index, columns=df.columns)


def scale_standard(df: pd.DataFrame):
    """
    Standardize time series data using Z-Score Normalization.
    """
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(df)
    return pd.DataFrame(scaled_data, index=df.index, columns=df.columns)


def remove_outliers(df: pd.DataFrame, threshold=3):
    """
    Remove outliers from time series based on Z-score.
    """
    z_scores = np.abs((df - df.mean()) / df.std())
    return df[(z_scores < threshold).all(axis=1)]


def difference_data(df: pd.DataFrame, periods=1):
    """
    Apply differencing to make the time series stationary.
    periods: Lag to difference.
    """
    return df.diff(periods=periods).dropna()


def decompose_timeseries(df: pd.DataFrame, model='additive', freq=None):
    """
    Decompose time series into trend, seasonality, and residual componendf.
    model: 'additive' or 'multiplicative'.
    freq: Seasonality frequency (number of periods in a cycle).
    """
    decomposition = seasonal_decompose(df, model=model, period=freq)
    return decomposition


def smooth_timeseries(df: pd.DataFrame, window_length=5, polyorder=2):
    """
    Apply Savitzky-Golay filter for smoothing time series data.
    window_length: The length of the filter window (i.e., the number of coefficiendf).
    polyorder: The order of the polynomial used to fit the samples.
    """
    smoothed_data = savgol_filter(df, window_length, polyorder, axis=0)
    return pd.DataFrame(smoothed_data, index=df.index, columns=df.columns)


def extract_dummy_features(df: pd.DataFrame):
    """
    Extract datetime-related dummy features from the DataFrame's datetime index.
    
    Parameters:
    - df: Input DataFrame with datetime index.
    
    Returns:
    - df: DataFrame with added dummy features.
    """
    # Ensure the index is datetime
    if not pd.api.types.is_datetime64_any_dtype(df.index):
        raise ValueError("The DataFrame index must be of datetime type")
    
    # Extracting day, month, year, and other time-related features
    df['day'] = df.index.day
    df['month'] = df.index.month
    df['year'] = df.index.year
    df['weekday'] = df.index.weekday  # Monday = 0, Sunday = 6
    df['is_weekend'] = df.index.weekday >= 5  # Saturday and Sunday are weekends
    df['is_weekend'] = df['is_weekend'].astype(int)
    df['week_of_year'] = df.index.isocalendar().week  # Week number of the year
    df['quarter'] = df.index.quarter  # Quarter of the year (1 to 4)
    
    df['is_month_start'] = df.index.is_month_start  # Is it the first day of the month?
    df['is_month_start'] = df['is_month_start'].astype(int)
    df['is_month_end'] = df.index.is_month_end  # Is it the last day of the month?
    df['is_month_end'] = df['is_month_end'].astype(int)

    return df


def create_robust_lag_features(df: pd.DataFrame, column: str, n_lags=3):
    """
    Create robust lag features for a specific column in a DataFrame with datetime index, including:
    - Last 3 days
    - Last week (7 days ago)
    - Same day of the last month (accounting for month lengths using relativedelta)
    - Same day of the last year (accounting for leap years using relativedelta)
    df: Input DataFrame with datetime index
    column: The column to create lag features for
    n_lags: Number of lag days to create for recent days.
    """
    # Ensure the index is datetime (needed for timedelta and relativedelta operations)
    if not pd.api.types.is_datetime64_any_dtype(df.index):
        raise ValueError("The DataFrame index must be of datetime type")
    
    lagged_df = pd.DataFrame(df.copy())

    # Last n_lags days (e.g., last 3 days)
    for lag in range(1, n_lags + 1):
        lagged_df[f'lag_{lag}_day'] = df[column].shift(lag)
    
    # Last week (7 days ago)
    lagged_df['lag_1_week'] = df[column].shift(7)
    
    # Same day of the last month (using relativedelta)
    lagged_df['lag_1_month'] = df.index.map(lambda x: df[column].loc[x - relativedelta(months=1)] if (x - relativedelta(months=1)) in df.index else pd.NA)
    
    # Same day of the last year (using relativedelta)
    lagged_df['lag_1_year'] = df.index.map(lambda x: df[column].loc[x - relativedelta(years=1)] if (x - relativedelta(years=1)) in df.index else pd.NA)
    
    # Drop rows with NaN values introduced by the lagging process
    return lagged_df.dropna()


def create_rolling_features(df: pd.DataFrame, target_col: str, windows: list):
    """
    Create rolling mean and standard deviation features.
    window: Size of the rolling window.
    """
    df_copy = df.copy()

    df_copy[f'{target_col}_cumsum'] = df[target_col].cumsum()
    df_copy[f'{target_col}_pct_change'] = df[target_col].pct_change()

    for window in windows:
        df_copy[f'{target_col}_{window}window_mean'] = df[target_col].rolling(window=window).mean()
        df_copy[f'{target_col}_{window}window_var'] = df[target_col].rolling(window=window).var()
        df_copy[f'{target_col}_{window}window_slope'] = df_copy[f'{target_col}_{window}window_mean'].diff()

        df_copy[f'{target_col}_{window}window_ema'] = df[target_col].ewm(span=window, adjust=False).mean() # Exponential Moving Average (EMA)
        df_copy[f'{target_col}_{window}window_rolling_max'] = df[target_col].rolling(window=window).max()
        df_copy[f'{target_col}_{window}window_rolling_min'] = df[target_col].rolling(window=window).min()
        df_copy[f'{target_col}_{window}window_skew'] = df[target_col].rolling(window=window).skew()
        df_copy[f'{target_col}_{window}window_kurt'] = df[target_col].rolling(window=window).kurt()
        df_copy[f'{target_col}_{window}window_pct_change_lag'] = df[target_col].pct_change(periods=window)
        
    return df_copy.dropna()


def interpolate_missing_values(df: pd.DataFrame, method='linear'):
    """
    Impute missing values using interpolation.
    method: Interpolation method ('linear', 'time', 'polynomial', etc.).
    """
    return df.interpolate(method=method)


def impute_missing_statistical(df: pd.DataFrame, strategy='mean'):
    """
    Impute missing values using statistical methods (mean, median, most_frequent).
    """
    imputer = SimpleImputer(strategy=strategy)
    imputed_data = imputer.fit_transform(df)
    return pd.DataFrame(imputed_data, index=df.index, columns=df.columns)


def detect_outliers_iqr(df: pd.DataFrame):
    """
    Detect outliers using Interquartile Range (IQR).
    """
    Q1 = df.quantile(0.25)
    Q3 = df.quantile(0.75)
    IQR = Q3 - Q1
    return df[((df < (Q1 - 1.5 * IQR)) | (df > (Q3 + 1.5 * IQR))).any(axis=1)]


def max_abs_scaler(df: pd.DataFrame):
    """
    Normalize time series data using Max Absolute Scaling.
    """
    scaler = MaxAbsScaler()
    scaled_data = scaler.fit_transform(df)
    return pd.DataFrame(scaled_data, index=df.index, columns=df.columns)


def plot_timeseries(df, columns=None, title='Time Series Plot'):
    """
    Plot time series data.
    df: Pandas DataFrame with time series index.
    columns: List of column names to plot. If None, all columns are plotted.
    title: Title of the plot.
    """
    
    plt.figure(figsize=(10, 5))
    if columns is None:
        columns = df.columns
    for col in columns:
        plt.plot(df.index, df[col], label=col)
    plt.title(title)
    plt.xlabel('Date')
    plt.ylabel('Value')
    plt.legend()
    plt.show()


def plot_timeseries_with_moving_average(df, columns=None, window=5, title='Time Series with Moving Average'):
    """
    Plot time series data along with its moving average.
    df: Pandas DataFrame with time series index.
    columns: List of column names to plot. If None, all columns are plotted.
    window: Window size for moving average.
    title: Title of the plot.
    """
    plt.figure(figsize=(10, 5))
    if columns is None:
        columns = df.columns
    for col in columns:
        plt.plot(df.index, df[col], label=f'{col}')
        plt.plot(df.index, df[col].rolling(window=window).mean(), label=f'{col} {window}-MA')
    plt.title(title)
    plt.xlabel('Date')
    plt.ylabel('Value')
    plt.legend()
    plt.show()


def plot_timeseries_with_multiple_mas(df, columns=None, windows=[5, 10, 20], title='Time Series with Multiple Moving Averages'):
    """
    Plot time series data along with multiple moving averages.
    df: Pandas DataFrame with time series index.
    columns: List of column names to plot. If None, the first column is plotted.
    windows: List of window sizes for moving averages.
    title: Title of the plot.
    """
    plt.figure(figsize=(10, 5))
    if columns is None:
        columns = [df.columns[0]]
    for col in columns:
        plt.plot(df.index, df[col], label=f'{col}')
        for window in windows:
            plt.plot(df.index, df[col].rolling(window=window).mean(), label=f'{col} {window}-MA')
    plt.title(title)
    plt.xlabel('Date')
    plt.ylabel('Value')
    plt.legend()
    plt.show()


def plot_timeseries_subplots(df, columns=None, title='Time Series Subplots'):
    """
    Plot multiple time series in subplots.
    df: Pandas DataFrame with time series index.
    columns: List of column names to plot. If None, all columns are plotted.
    title: Title of the plot.
    """
    if columns is None:
        columns = df.columns
    n_plots = len(columns)
    fig, axes = plt.subplots(n_plots, 1, figsize=(12, 4 * n_plots), sharex=True)
    for i, col in enumerate(columns):
        axes[i].plot(df.index, df[col], label=col)
        axes[i].set_title(f'{col}')
        axes[i].set_xlabel('Date')
        axes[i].set_ylabel('Value')
        axes[i].legend()
    plt.suptitle(title)
    plt.tight_layout()
    plt.show()


def plot_seasonal_decompose(df, column=None, model='additive', freq=None):
    """
    Plot the seasonal decomposition of a time series.
    df: Pandas DataFrame with time series index.
    column: Column name to decompose. If None, the first column is used.
    model: 'additive' or 'multiplicative'.
    freq: Seasonal frequency.
    """
    if column is None:
        column = df.columns[0]
    decomposition = seasonal_decompose(df[column], model=model, period=freq)
    fig = decomposition.plot()
    fig.set_size_inches(12, 8)
    plt.show()


def plot_acf_timeseries(df, column=None, lags=30):
    """
    Plot the autocorrelation function of a time series.
    df: Pandas DataFrame with time series index.
    column: Column name to plot ACF for. If None, the first column is used.
    lags: Number of lags to display.
    """
    if column is None:
        column = df.columns[0]
    plot_acf(df[column], lags=lags)
    plt.show()


def plot_timeseries_heatmap(df: pd.DataFrame, title='Time Series Heatmap'):
    """
    Plot a heatmap of the time series data.
    df: Pandas DataFrame with time series index.
    title: Title of the plot.
    """
    # Set the size of the figure to fit 42 columns properly
    plt.figure(figsize=(21, 16))
    
    # Calculate the correlation matrix
    corr = df.corr()
    
    # Create a mask for the upper triangle
    mask = np.triu(np.ones_like(corr, dtype=bool))
    
    # Generate the heatmap with adjusted settings
    sns.heatmap(
        corr,
        annot=True,          # Display the correlation values
        fmt=".2f",           # Limit decimal places in annotations
        cmap='coolwarm',     # Use the coolwarm color map
        mask=mask,           # Mask the upper triangle
        cbar_kws={"shrink": .80},  # Shrink the color bar size
        linewidths=0.5,      # Line width for grid lines between squares
        annot_kws={"size": 9},  # Adjust annotation font size
        vmin=-1, vmax=1      # Ensure the color scale is consistent
    )
    
    # Set plot title and display the heatmap
    plt.title(title, fontsize=16)
    plt.xticks(rotation=90)  # Rotate x-axis labels to prevent overlap
    plt.yticks(rotation=0)   # Keep y-axis labels horizontal
    plt.tight_layout()       # Adjust layout to fit everything
    plt.show()


def add_holiday_column(df: pd.DataFrame, us_state: str):
    """
    Add a column to the DataFrame indicating whether each date is a holiday.
    The DataFrame index should be of datetime type and represent dates.
    
    Parameters:
    - df: Input DataFrame with datetime index representing Philadelphia time series data.
    
    Returns:
    - df: DataFrame with an added 'is_holiday' column (True for holidays, False otherwise).
    """
    # Ensure the index is datetime
    if not pd.api.types.is_datetime64_any_dtype(df.index):
        raise ValueError("The DataFrame index must be of datetime type")
    
    # Define U.S. holidays, restricted to Pennsylvania (where Philadelphia is located)
    us_holidays = holidays.US(state=us_state)
    
    # Add a new column 'is_holiday', which checks if each date in the index is a holiday
    df['is_holiday'] = df.index.map(lambda x: int(x in us_holidays))
    
    return df


def add_crisis_and_covid_columns(df: pd.DataFrame, covid_start='2020-03-11', covid_end='2023-05-05', additional_crisis_periods=None):
    """
    Add columns to the DataFrame indicating if a date falls within the COVID-19 period or other crisis periods.
    
    Parameters:
    - df: Input DataFrame with datetime index representing time series data.
    - covid_start: Start date of the COVID-19 period (default: March 2020).
    - covid_end: End date of the COVID-19 period (default: May 2023).
    - additional_crisis_periods: A list of tuples, where each tuple contains the start and end date of a crisis.
                      Example: [('2008-09-01', '2009-06-30')] for the Financial Crisis.
    
    Returns:
    - df: DataFrame with added 'is_covid_period' and 'is_crisis_period' columns.
    """
    # Ensure the index is datetime
    if not pd.api.types.is_datetime64_any_dtype(df.index):
        raise ValueError("The DataFrame index must be of datetime type")
    
    # Convert the COVID-19 start and end dates to datetime objects
    covid_start = pd.to_datetime(covid_start)
    covid_end = pd.to_datetime(covid_end)
    
    # Add 'is_covid_period' column: True if date falls during the COVID-19 pandemic
    df['is_covid_period'] = df.index.map(lambda x: int(covid_start <= x <= covid_end))
    
    # If any additional crisis periods are provided, check and flag them
    if additional_crisis_periods:
        # Initialize the 'is_crisis_period' column to False
        df['is_crisis_period'] = 0
        
        for start, end in additional_crisis_periods:
            start_date = pd.to_datetime(start)
            end_date = pd.to_datetime(end)
            df['is_crisis_period'] = df['is_crisis_period'] | df.index.map(lambda x: int(start_date <= x <= end_date))
    
    return df


def apply_fourier_transformation(df: pd.DataFrame, target_col: str):
    """
    Apply Fourier transformation to all date-related features in the DataFrame.
    
    Parameters:
    - df: Input DataFrame containing date-related features.
    - target_col: Name of the target column to exclude from transformation.
    
    Returns:
    - df: DataFrame with Fourier transformed features added.
    """
    # Ensure the DataFrame contains numeric columns for Fourier transformation
    numeric_cols = df.select_dtypes(include=[np.number]).columns.tolist()
    
    # Exclude columns that start with "is" and the target column if specified
    numeric_cols = [col for col in numeric_cols if not col.startswith("is") 
                    and col != target_col 
                    and not col.startswith("lag")
                    and not col.startswith(f"{target_col}")
                    and not col.startswith("economy")]

    df_copy = df.copy()
    # Apply Fourier transformation to the selected numeric columns
    for col in numeric_cols:
        # Perform the Fourier transform
        aux_df = df[[col]].reset_index(names="ds")
        aux_df.insert(0, "unique_id", 1)
        transformed_df, _ = fourier(aux_df, freq='D', season_length=7, k=2, h=1)
        transformed_df = transformed_df.set_index("ds")
        transformed_df = transformed_df.iloc[:, -4:]
        transformed_df = transformed_df.add_prefix(f"{col}_", axis=1)
        df_copy = df_copy.join(transformed_df)

    return df_copy


def fetch_and_merge_economic_data(df: pd.DataFrame) -> pd.DataFrame:
    """
    Fetch economic data and merge it with the existing DataFrame.
    
    Parameters:
    - df: DataFrame containing your time series data (e.g., restaurant check-ins).
    - start: Start date for fetching economic data.
    - end: End date for fetching economic data.

    Returns:
    - Merged DataFrame with economic indicators.
    """
    sorted_index = sorted(df.index)
    start = sorted_index[0]
    end = sorted_index[-1]
    print(type(df.index), type(end))

    # Fetch economic data
    unemployment_rate = web.DataReader('UNRATE', 'fred', start, end).rename(columns={"UNRATE": "economy_employment_rate"}).resample("D").ffill()
    consumer_confidence = web.DataReader('UMCSENT', 'fred', start, end).rename(columns={"UMCSENT": "economy_consumer_confidence"}).resample("D").ffill()
    gdp = web.DataReader('GDP', 'fred', start, end).rename(columns={"GDP": "economy_gdp"}).resample("D").ffill()
    cpi_us = web.DataReader('CPIAUCNS', 'fred', start, end)
    cpi_us['economy_inflation_rate'] = cpi_us['CPIAUCNS'].pct_change() * 100
    cpi_us = cpi_us.rename(columns={"CPIAUCNS": "cpi"}).resample("D").ffill()

    # Merging the economic data into the existing DataFrame
    merged_df = df.merge(unemployment_rate, left_index=True, right_index=True, how='left').ffill()
    merged_df = merged_df.merge(consumer_confidence, left_index=True, right_index=True, how='left').ffill()
    merged_df = merged_df.merge(gdp, left_index=True, right_index=True, how='left').ffill()
    merged_df = merged_df.merge(cpi_us.drop(columns="cpi"), left_index=True, right_index=True, how='left').ffill()

    return merged_df