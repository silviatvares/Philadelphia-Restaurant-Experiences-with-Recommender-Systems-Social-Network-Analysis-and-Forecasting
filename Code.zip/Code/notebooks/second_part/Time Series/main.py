import numpy as np
from statsforecast import StatsForecast
from statsforecast.models import Naive
from models.baseline_model import BaselineModel
from models.linear_regression_model import LinearRegressionModel
from models.random_forest_model import RandomForestModel
from models.xgboost_model import XGBoostModel
import pandas as pd
from utils.evaluation import Evaluator
from utils.timeseriescv import TimeBasedCV
from sklearn.model_selection import TimeSeriesSplit
from sklearn.linear_model import LinearRegression
from xgboost import XGBRegressor
from sklearn.ensemble import RandomForestRegressor
import seaborn as sns
import matplotlib.pyplot as plt
from statsforecast.models import AutoARIMA


# # Example DataFrame with a datetime index
data = pd.read_csv("final_timeseries.csv", parse_dates=["date"], index_col="date")

def cross_validation(df: pd.DataFrame, horizon: int = 31):

    models = {
    # "baseline": StatsForecast(models=[Naive(alias="last_value")], freq='D'),
    # "xgboost": XGBRegressor(n_estimators=500, learning_rate=0.1, max_depth=5),
    # "random_forest": RandomForestRegressor(n_estimators=100, random_state=42),
    # "linear_regression": LinearRegression(),
    "arima": AutoARIMA(trace=True)
    }

    
    errors = {}
    predictions = {}


    # dummy model to get final df
    final_df = BaselineModel(df, target_column="checkins", horizon=31).preprocess_data().reset_index(names="date")
    tscv = TimeBasedCV(train_period=len(final_df) - horizon - 1, test_period=1, freq="days")
    split_cv_dates = tscv.split(final_df, date_column="date", gap=0)

    for model_name, model in models.items():
        for train_index, test_index in split_cv_dates:
            print(train_index[-1], test_index[-1])
            train = final_df.iloc[train_index].set_index("date")
            x_train = train.drop(columns="checkins")
            y_train = train["checkins"]
            valid = final_df.iloc[test_index].set_index("date")
            x_test = valid.drop(columns="checkins")
            y_test = valid["checkins"].values

            # if "statsforecast" in str(model.__class__).lower():
            if True:
                # y_train = y_train.reset_index()
                # y_train.columns = ["ds", "y"]
                # y_train["unique_id"] = 0
                model.fit(y_train)
                # prediction = model.predict(h=1, level=[80, 95]).iloc[:, -1].values[0]
                prediction = model.predict(h=1, level=[80, 95])["mean"]
            else:
                model.fit(x_train, y_train)
                prediction = model.predict(x_test)[0]

            err = abs(y_test[0] - prediction)
            if model_name not in errors.keys():
                errors[model_name] = [err]
            else:
                errors[model_name].append(err)
            
            if model_name not in predictions.keys():
                predictions[model_name] = [prediction]
            else:
                predictions[model_name].append(prediction)

            print(model_name)
            
    return predictions, errors



# #Select model

models = {
    "baseline": BaselineModel(data, target_column="checkins", horizon=31),
    "xgboost": XGBoostModel(data, target_column='checkins', horizon=31),
    "random_forest": RandomForestModel(data, target_column="checkins", horizon=31),
    "linear_regression": LinearRegressionModel(data, target_column="checkins", horizon=31)
    }

evaluator = Evaluator()

for model_name, model in models.items():
    model.pipeline()
    predictions = model.predict(model.X_test)
    # evaluator.evaluate_model(model_name, model.y_test.values.ravel(), predictions)
    evaluator.evaluate_and_plot(model_name, model.y_train.iloc[-model.horizon * 4:], model.y_test[:-2], pred)

evaluator.compare_models_metrics()


# evaluator.compare_models_metrics()

# predictions, errors = cross_validation(data, horizon=31)
# print(errors)
# print(predictions)
# # evaluator = Evaluator()
# # evaluator.plot_errors_cv_comparison(errors)
# for model_name, pred in predictions.items():
#     evaluator.plot_forecast_vs_actual(final_df["checkins"].iloc[-31 * 4:-31],
#                                       final_df["checkins"].iloc[-31:], 
#                                       pred,
#                                       model_name
#                                       )
